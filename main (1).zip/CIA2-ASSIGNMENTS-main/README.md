# CIA2-ASSIGNMENTS

<img src="/Output/info.png">
<img src="/Output/question.png">
<img src="/Output/custom.png">
<img src="/Output/NID.png">
<img src="/Output/warning.png">
<img src="/Output/off.png">
<img src="/Output/on.png">
<img src="/Output/combobox.png">
